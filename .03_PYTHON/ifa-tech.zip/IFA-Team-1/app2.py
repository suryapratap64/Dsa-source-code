import io
import pandas as pd
import numpy as np
import streamlit as st

# ---------------------------
# Page config
# ---------------------------
st.set_page_config(page_title="Sports Data Feature Engineer", layout="wide")
st.title("Sports Feature Engineering")
st.caption(
    "Upload an Excel/CSV of sports matches, map the relevant columns, and transform each match into two team-rows with useful ML features (favorite/underdog, result, implied probabilities, etc.)."
)

# ---------------------------
# Helpers
# ---------------------------

def try_convert_numeric(series):
    """Best-effort convert to numeric without failing the app."""
    return pd.to_numeric(series, errors="coerce")


def normalized_probs(odds_home, odds_away, odds_draw=None):
    """Return normalized probabilities from decimal odds (removes the overround)."""
    inv_home = 1.0 / odds_home if odds_home and odds_home > 0 else np.nan
    inv_away = 1.0 / odds_away if odds_away and odds_away > 0 else np.nan
    inv_draw = 1.0 / odds_draw if odds_draw and odds_draw > 0 else 0.0
    total = np.nansum([inv_home, inv_away, inv_draw])
    if total == 0 or np.isnan(total):
        return np.nan, np.nan, (np.nan if odds_draw is not None else None)
    return inv_home / total, inv_away / total, (inv_draw / total if odds_draw is not None else None)


def transform_matches_to_team_rows(
    df,
    *,
    match_id_col=None,
    date_col=None,
    league_col=None,
    home_team_col=None,
    away_team_col=None,
    ftr_col=None,  # full-time result column (e.g., H/A/D, Home/Away/Draw, 1/2/X, etc.)
    ftr_home_code="H",
    ftr_away_code="A",
    ftr_draw_code="D",
    home_goals_col=None,
    away_goals_col=None,
    odds_home_col=None,
    odds_away_col=None,
    odds_draw_col=None,
):
    """General function: one match-row -> two team-rows with engineered features.

    Returns: (long_df, info_dict)
    """
    work = df.copy()

    # Create a Match ID if missing
    if match_id_col and match_id_col in work.columns:
        match_id = work[match_id_col]
    else:
        match_id = pd.Series(range(1, len(work) + 1), index=work.index, name="MatchID")
        work["MatchID"] = match_id
        match_id_col = "MatchID"

    # Odds as numerics
    for c in [odds_home_col, odds_away_col, odds_draw_col]:
        if c and c in work.columns:
            work[c] = try_convert_numeric(work[c])

    # Goals as numerics (optional)
    for c in [home_goals_col, away_goals_col]:
        if c and c in work.columns:
            work[c] = try_convert_numeric(work[c])

    # Build per-row records for Home and Away
    records = []
    for idx, row in work.iterrows():
        mid = row[match_id_col]
        date_val = row[date_col] if date_col and date_col in work.columns else None
        league_val = row[league_col] if league_col and league_col in work.columns else None

        home = row[home_team_col] if home_team_col else None
        away = row[away_team_col] if away_team_col else None

        ftr_val = row[ftr_col] if ftr_col and ftr_col in work.columns else None
        ftr_str = str(ftr_val).strip() if (ftr_val is not None and not pd.isna(ftr_val)) else None

        hg = row[home_goals_col] if home_goals_col and home_goals_col in work.columns else None
        ag = row[away_goals_col] if away_goals_col and away_goals_col in work.columns else None

        oh = row[odds_home_col] if odds_home_col and odds_home_col in work.columns else None
        oa = row[odds_away_col] if odds_away_col and odds_away_col in work.columns else None
        od = row[odds_draw_col] if odds_draw_col and odds_draw_col in work.columns else None

        # Favorite/underdog based on lower odds (if both provided)
        fav_team = None
        udog_team = None
        if pd.notna(oh) and pd.notna(oa):
            if oh < oa:
                fav_team, udog_team = "Home", "Away"
            elif oa < oh:
                fav_team, udog_team = "Away", "Home"
            else:
                fav_team, udog_team = "Co-favorites", "Co-favorites"

        # Normalized probabilities (remove the overround)
        p_home, p_away, p_draw = normalized_probs(oh, oa, od if odds_draw_col else None)

        # Build two rows: Home perspective and Away perspective
        for role, team, opp, odds_team, odds_opp, goals_for, goals_against in [
            ("Home", home, away, oh, oa, hg, ag),
            ("Away", away, home, oa, oh, ag, hg),
        ]:
            if team is None or opp is None:
                continue

            # Per-team result label
            team_result = None
            if ftr_str:
                if ftr_str == ftr_draw_code:
                    team_result = "Draw"
                elif (role == "Home" and ftr_str == ftr_home_code) or (role == "Away" and ftr_str == ftr_away_code):
                    team_result = "Win"
                else:
                    team_result = "Loss"

            # Favorite flags from match-level favorite
            is_favorite = None
            is_underdog = None
            if fav_team:
                if fav_team == "Co-favorites":
                    is_favorite = True
                    is_underdog = True
                else:
                    is_favorite = (role == fav_team)
                    is_underdog = (role == udog_team)

            # Team-level implied probabilities, normalized
            prob_team = None
            prob_opp = None
            if role == "Home":
                prob_team = p_home
                prob_opp = p_away
            elif role == "Away":
                prob_team = p_away
                prob_opp = p_home

            rec = {
                "MatchID": mid,
                "Date": date_val,
                "League": league_val,
                "Team": team,
                "Role": role,  # Home/Away
                "Opponent": opp,
                "FTR_raw": ftr_str,  # match result code as-is
                "TeamResult": team_result,  # Win/Loss/Draw from team perspective
                "GoalsFor": goals_for,
                "GoalsAgainst": goals_against,
                "GoalDiff": (goals_for - goals_against) if pd.notna(goals_for) and pd.notna(goals_against) else np.nan,
                "Odds_Team": odds_team,
                "Odds_Opp": odds_opp,
                "ImpliedProb_Team": (1.0 / odds_team) if odds_team and odds_team > 0 else np.nan,
                "ImpliedProb_Opp": (1.0 / odds_opp) if odds_opp and odds_opp > 0 else np.nan,
                "NormProb_Team": prob_team,
                "NormProb_Opp": prob_opp,
                "FavoriteTeam": fav_team,
                "IsFavorite": is_favorite,
                "IsUnderdog": is_underdog,
            }
            if odds_draw_col:
                rec["Odds_Draw"] = od
                rec["NormProb_Draw"] = p_draw
            records.append(rec)

    long_df = pd.DataFrame.from_records(records)

    info = {
        "n_matches": len(work),
        "n_team_rows": len(long_df),
        "has_draw_odds": bool(odds_draw_col),
    }
    return long_df, info


# ---------------------------
# Sidebar – Upload & Mapping
# ---------------------------
st.sidebar.header("1) Upload your data")
file = st.sidebar.file_uploader("Excel (.xlsx/.xls) or CSV", type=["xlsx", "xls", "csv"]) 

sheet_name = None
raw_df = None
if file is not None:
    if file.name.lower().endswith((".xlsx", ".xls")):
        xls = pd.ExcelFile(file)
        sheet_name = st.sidebar.selectbox("Sheet", options=xls.sheet_names, index=0)
        raw_df = xls.parse(sheet_name)
    else:
        # CSV
        sep = st.sidebar.selectbox("CSV delimiter", [",", ";", "\t", "|"], index=0)
        raw_df = pd.read_csv(file, sep=sep)

if raw_df is not None:
    st.subheader("Preview — Raw Data")
    st.dataframe(raw_df.head(25), use_container_width=True)

    st.sidebar.header("2) Map columns (keep it general)")
    cols = list(raw_df.columns)

    match_id_col = st.sidebar.selectbox("Match ID (optional)", options=[None] + cols, index=0)
    date_col = st.sidebar.selectbox("Date (optional)", options=[None] + cols, index=0)
    league_col = st.sidebar.selectbox("League/Division (optional)", options=[None] + cols, index=0)

    home_team_col = st.sidebar.selectbox("Home Team column", options=cols)
    away_team_col = st.sidebar.selectbox("Away Team column", options=cols)

    ftr_col = st.sidebar.selectbox("Full-Time Result column (e.g., H/A/D or Home/Away/Draw)", options=[None] + cols, index=0)

    with st.sidebar.expander("Result codes (only if you selected a result column)"):
        ftr_home_code = st.text_input("Code for Home win", value="H")
        ftr_away_code = st.text_input("Code for Away win", value="A")
        ftr_draw_code = st.text_input("Code for Draw", value="D")

    home_goals_col = st.sidebar.selectbox("Home goals (optional)", options=[None] + cols, index=0)
    away_goals_col = st.sidebar.selectbox("Away goals (optional)", options=[None] + cols, index=0)

    st.sidebar.subheader("Odds mapping (decimal odds)")
    odds_home_col = st.sidebar.selectbox("Odds — Home (required for favorite/underdog)", options=[None] + cols, index=0)
    odds_away_col = st.sidebar.selectbox("Odds — Away (required for favorite/underdog)", options=[None] + cols, index=0)
    odds_draw_col = st.sidebar.selectbox("Odds — Draw (optional)", options=[None] + cols, index=0)

    st.sidebar.header("3) Transform")
    go = st.sidebar.button("Transform to team-rows & engineer features")

    if go:
        long_df, info = transform_matches_to_team_rows(
            raw_df,
            match_id_col=match_id_col,
            date_col=date_col,
            league_col=league_col,
            home_team_col=home_team_col,
            away_team_col=away_team_col,
            ftr_col=ftr_col,
            ftr_home_code=ftr_home_code,
            ftr_away_code=ftr_away_code,
            ftr_draw_code=ftr_draw_code,
            home_goals_col=home_goals_col,
            away_goals_col=away_goals_col,
            odds_home_col=odds_home_col,
            odds_away_col=odds_away_col,
            odds_draw_col=odds_draw_col,
        )

        st.success(
            f"Transformed {info['n_matches']} match-rows into {info['n_team_rows']} team-rows."
        )

        # Suggested feature set ordering for ML
        feature_cols = [
            "MatchID", "Date", "League", "Team", "Role", "Opponent",
            "FTR_raw", "TeamResult", "GoalsFor", "GoalsAgainst", "GoalDiff",
            "Odds_Team", "Odds_Opp", "ImpliedProb_Team", "ImpliedProb_Opp",
            "NormProb_Team", "NormProb_Opp", "FavoriteTeam", "IsFavorite", "IsUnderdog",
        ]
        if odds_draw_col:
            feature_cols += ["Odds_Draw", "NormProb_Draw"]

        # Render preview
        show_cols = [c for c in feature_cols if c in long_df.columns]
        st.subheader("Engineered Team-Level Dataset")
        st.dataframe(long_df[show_cols].head(50), use_container_width=True)

        # Download
        csv_bytes = long_df.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="Download engineered CSV",
            data=csv_bytes,
            file_name="engineered_team_rows.csv",
            mime="text/csv",
        )

        # Quick quality checks & summaries
        st.subheader("Quick Checks & Summaries")
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Matches", info["n_matches"])
        with col2:
            st.metric("Team Rows", info["n_team_rows"])
        with col3:
            st.metric("Has Draw Odds", "Yes" if info["has_draw_odds"] else "No")
        with col4:
            if "TeamResult" in long_df.columns:
                st.metric("Win rows", int((long_df["TeamResult"] == "Win").sum()))

else:
    st.info(
        "Upload a sheet with at least Home Team, Away Team, and (ideally) Home/Away odds. Result and goals are optional but recommended."
    )


