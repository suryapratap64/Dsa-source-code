# app.py
# -----------------------------------------------------------------------------
# Universal Matchwise → Teamwise Excel Converter (General, No Hardcoded Columns)
# -----------------------------------------------------------------------------
# Features:
# - Upload any Excel file/sheet with match-level rows.
# - Dynamically choose Home Team column, Away Team column.
# - Optionally map Home/Away stat columns into unified stat names (e.g., Shots).
# - Optionally select generic columns to carry to both rows unchanged.
# - Optionally select Home/Away player columns → melt to a single "PlayerName" column.
# - Outputs Teamwise rows (2 per match), optional Players Long table, and a combined
#   Excel download with multiple sheets.
#
# Notes:
# - No dependency on specific betting or football-only columns.
# - Robust to missing pieces: works with teams-only, with stats, with players, or any mix.
# - Provides heuristics to auto-detect candidate columns, but everything is user-selectable.
#
# Requirements:
#   pip install streamlit pandas openpyxl
#
# Run:
#   streamlit run app.py
# -----------------------------------------------------------------------------

from __future__ import annotations

import io
import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import pandas as pd
import streamlit as st


# =============================== Config ======================================

st.set_page_config(page_title="Universal Match → Teamwise Converter", layout="wide")


# ========================= Small Utility Helpers =============================

def df_head_safe(df: pd.DataFrame, n: int = 15) -> pd.DataFrame:
    """Return first n rows if df exists; otherwise empty frame."""
    if df is None or df.empty:
        return pd.DataFrame()
    return df.head(n)


def to_categoricals(df: pd.DataFrame, exclude: Optional[List[str]] = None) -> pd.DataFrame:
    """Convert object/string columns to pandas 'category' to reduce memory size."""
    exclude = set(exclude or [])
    out = df.copy()
    for c in out.columns:
        if c in exclude:
            continue
        if pd.api.types.is_object_dtype(out[c]) or pd.api.types.is_string_dtype(out[c]):
            out[c] = out[c].astype("category")
    return out


def bytes_excel_multi(sheets: Dict[str, pd.DataFrame]) -> bytes:
    """Write multiple DataFrames to one Excel file (each as its own sheet)."""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl", mode="wb") as writer:
        for sheet_name, frame in sheets.items():
            frame.to_excel(writer, index=False, sheet_name=sheet_name[:31] or "Sheet")
        writer.save()
    buf.seek(0)
    return buf.getvalue()


def safe_list(val) -> List[str]:
    """Ensure value is a list of strings."""
    if val is None:
        return []
    if isinstance(val, (list, tuple, set)):
        return [str(x) for x in val]
    return [str(val)]


def normalize_label(label: str) -> str:
    """
    Normalize a column label to help pair Home/Away stats.
    Examples:
        "HomeShots" -> "shots"
        "HST" -> "st" (we'll still try to pair heuristically)
        "Away Fouls" -> "fouls"
    """
    s = re.sub(r"[_\-\s]+", "", str(label)).strip()
    s = s.lower()
    # remove common home/away prefixes
    s = re.sub(r"^(home|away|h|a)", "", s)
    return s


def guess_team_columns(columns: List[str]) -> Tuple[Optional[str], Optional[str]]:
    """Heuristic: try to guess Home and Away team columns by name."""
    home = None
    away = None
    for c in columns:
        cl = c.lower()
        if home is None and ("hometeam" in cl or (cl.startswith("home") and "team" in cl)):
            home = c
        if away is None and ("awayteam" in cl or (cl.startswith("away") and "team" in cl)):
            away = c
    # fallback: any columns containing 'home'/'away'
    if home is None:
        for c in columns:
            if c.lower().startswith("home"):
                home = c
                break
    if away is None:
        for c in columns:
            if c.lower().startswith("away"):
                away = c
                break
    return home, away


def detect_home_away_stat_pairs(columns: List[str]) -> List[Tuple[str, str, str]]:
    """
    Attempt to find stat pairs like:
      - ("HS", "AS", "S") or ("HomeShots", "AwayShots", "shots")
    Return list of tuples: (home_col, away_col, unified_name)
    """
    cols = list(columns)
    result = []
    used = set()

    # mapping ideas to pair "H*" with "A*" or "Home*" with "Away*"
    for i in range(len(cols)):
        c1 = cols[i]
        if c1 in used:
            continue
        c1l = c1.lower()
        if c1l.startswith("home") or c1l.startswith("h"):
            base = normalize_label(c1)
            # find away counterpart
            for j in range(len(cols)):
                if i == j:
                    continue
                c2 = cols[j]
                if c2 in used:
                    continue
                c2l = c2.lower()
                if c2l.startswith("away") or c2l.startswith("a"):
                    if normalize_label(c2) == base:
                        unified = re.sub(r"[_\-\s]+", "", base)
                        unified = unified if unified else base or "stat"
                        result.append((c1, c2, unified))
                        used.add(c1)
                        used.add(c2)
                        break

    # very simple pass to catch "FTHG/FTAG" style (N.B.: not strictly home/away prefixed)
    # if a column ends with 'hg' and there's a twin ending with 'ag', consider them a pair
    def tail_pair(a: str, b: str, tail_a: str, tail_b: str, name: str):
        return a.lower().endswith(tail_a) and b.lower().endswith(tail_b), name

    rem = [c for c in cols if c not in used]
    for i in range(len(rem)):
        for j in range(i + 1, len(rem)):
            c1 = rem[i]
            c2 = rem[j]
            ok, nm = tail_pair(c1, c2, "hg", "ag", "goals")  # FTHG / FTAG, HTHG / HTAG
            if ok and c1 not in used and c2 not in used:
                result.append((c1, c2, nm))
                used.add(c1)
                used.add(c2)

    return result


# ========================== Data Transform Logic =============================

@dataclass
class TransformConfig:
    home_team_col: str
    away_team_col: str
    carry_cols: List[str]                   # copied to both rows
    stat_pairs: List[Tuple[str, str, str]] # (home_col, away_col, unified_name)
    player_cols_home: List[str]
    player_cols_away: List[str]
    create_categoricals: bool = True       # make string cols categorical
    match_id_col: Optional[str] = None     # optional existing match id col


def create_match_ids(df: pd.DataFrame, match_id_col: Optional[str]) -> pd.Series:
    """Return a Series for MatchID: use existing if provided, else 1..N."""
    if match_id_col and match_id_col in df.columns:
        sid = df[match_id_col].copy()
        # best-effort ensure uniqueness; if nulls, fill with index
        if sid.isna().any():
            sid = sid.fillna(range(1, len(df) + 1))
        return sid
    return pd.Series(range(1, len(df) + 1), index=df.index, name="MatchID")


def to_teamwise(df: pd.DataFrame, cfg: TransformConfig) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Core converter:
    - Produces teamwise rows (2 per match): columns [MatchID, Team, Opponent, Home/Away, <stats>, <carries>]
    - Produces players long table: columns [MatchID, Team, Home/Away, PlayerName]
    Returns: (teamwise_df, players_long_df)
    """
    if cfg.home_team_col not in df.columns or cfg.away_team_col not in df.columns:
        raise ValueError("Please select valid Home Team and Away Team columns present in your file.")

    # Build MatchID
    match_ids = create_match_ids(df, cfg.match_id_col)

    # Base sides
    home = pd.DataFrame({
        "MatchID": match_ids,
        "Team": df[cfg.home_team_col],
        "Opponent": df[cfg.away_team_col],
        "Home/Away": "Home",
    })
    away = pd.DataFrame({
        "MatchID": match_ids,
        "Team": df[cfg.away_team_col],
        "Opponent": df[cfg.home_team_col],
        "Home/Away": "Away",
    })

    # Carry columns (copied to both)
    for c in cfg.carry_cols:
        if c in df.columns:
            home[c] = df[c]
            away[c] = df[c]

    # Stat pairs (map to unified stat names)
    # For a stat named 'Shots', we produce two columns in the combined output:
    # 'Shots' value depends on side (home vs away) — i.e., we attach per side separately.
    # To keep columns simple, we'll create side-local columns, e.g., 'Shots' for whichever side
    # the row belongs to.
    # If you want both 'ShotsFor'/'ShotsAgainst', you'd compute later after merge; here we keep it simple.
    for h_col, a_col, unified in cfg.stat_pairs:
        # unique safe column name for output
        stat_name = unified.strip() or "stat"
        # ensure no collision with carry cols by appending suffix if needed
        if stat_name in home.columns or stat_name in away.columns:
            # add suffix to avoid overwrite
            stat_name_home = f"{stat_name}_val"
        else:
            stat_name_home = stat_name

        if h_col in df.columns:
            home[stat_name_home] = df[h_col]
        if a_col in df.columns:
            away[stat_name_home] = df[a_col]

    # Combine sides
    teamwise = pd.concat([home, away], ignore_index=True)

    # Players long
    players_rows = []
    if cfg.player_cols_home or cfg.player_cols_away:
        for i, row in df.iterrows():
            mid = match_ids.iloc[i]
            home_team = row[cfg.home_team_col]
            away_team = row[cfg.away_team_col]

            for c in cfg.player_cols_home:
                if c in df.columns:
                    pname = row[c]
                    if pd.notna(pname) and str(pname).strip():
                        players_rows.append({
                            "MatchID": mid,
                            "Team": home_team,
                            "Home/Away": "Home",
                            "PlayerName": pname,
                        })
            for c in cfg.player_cols_away:
                if c in df.columns:
                    pname = row[c]
                    if pd.notna(pname) and str(pname).strip():
                        players_rows.append({
                            "MatchID": mid,
                            "Team": away_team,
                            "Home/Away": "Away",
                            "PlayerName": pname,
                        })
    players_long = pd.DataFrame(players_rows) if players_rows else pd.DataFrame(
        columns=["MatchID", "Team", "Home/Away", "PlayerName"]
    )

    # Optionally cast to categoricals for memory efficiency
    if cfg.create_categoricals:
        teamwise = to_categoricals(teamwise, exclude=["MatchID"])
        if not players_long.empty:
            players_long = to_categoricals(players_long, exclude=["MatchID"])

    return teamwise, players_long


# =============================== UI / App ====================================

st.title("🏟️ Universal Match → Teamwise Converter (Excel)")
st.write(
    "Upload **any** Excel file with match-level rows. Pick the columns that represent "
    "**Home Team**, **Away Team**, optional **stat** columns (paired Home/Away), and optional "
    "**player name** columns for each side. The app will reshape into **teamwise** rows "
    "(two per match) and optionally a **players-long** table (one row per player with Home/Away)."
)

uploaded = st.file_uploader("Upload Excel (.xlsx/.xls)", type=["xlsx", "xls"])

sheet_df: Optional[pd.DataFrame] = None

if uploaded:
    try:
        # If multi-sheet, let user pick
        xls = pd.ExcelFile(uploaded)
        sheet_names = xls.sheet_names
        st.info(f"Detected {len(sheet_names)} sheet(s).")
        sheet = st.selectbox("Choose sheet", sheet_names, index=0)
        sheet_df = pd.read_excel(uploaded, sheet_name=sheet)

        st.success(f"Loaded sheet '{sheet}' with {len(sheet_df)} rows and {len(sheet_df.columns)} columns.")
        with st.expander("Preview original data (first 15 rows)", expanded=False):
            st.dataframe(df_head_safe(sheet_df), use_container_width=True, height=360)

        # --------------------- Column Selections -----------------------------

        st.subheader("1) Choose the Team Columns")

        col_home_guess, col_away_guess = guess_team_columns(sheet_df.columns.tolist())

        c1, c2, c3 = st.columns([1, 1, 1])
        with c1:
            home_col = st.selectbox(
                "Home Team column",
                options=sheet_df.columns.tolist(),
                index=(sheet_df.columns.get_loc(col_home_guess) if col_home_guess in sheet_df.columns else 0),
                help="Pick the column that contains the home side team name for each match.",
            )
        with c2:
            away_col = st.selectbox(
                "Away Team column",
                options=sheet_df.columns.tolist(),
                index=(sheet_df.columns.get_loc(col_away_guess) if col_away_guess in sheet_df.columns else 0),
                help="Pick the column that contains the away side team name for each match.",
            )
        with c3:
            match_id_col = st.selectbox(
                "Optional: Existing Match ID column (or leave blank to auto-generate)",
                options=[""] + sheet_df.columns.tolist(),
                index=0,
            )
        match_id_col = match_id_col or None

        st.divider()

        st.subheader("2) (Optional) Map Home/Away Stat Pairs → Unified Names")

        # Try to auto-detect pairs
        auto_pairs = detect_home_away_stat_pairs(sheet_df.columns.tolist())

        st.caption(
            "Detected pairs are suggested below. You can edit/add/remove pairs.\n"
            "Example: map (HomeShots, AwayShots) → 'Shots', (HST, AST) → 'OnTarget'."
        )

        # Editable pair list via simple dynamic widgets
        pair_container = st.container()
        pairs: List[Tuple[str, str, str]] = []

        # Provide a small number of rows to edit: detected + manual add slots
        default_rows = max(len(auto_pairs), 4)
        for i in range(default_rows):
            with pair_container:
                cols = st.columns([1.15, 1.15, 0.8, 0.2])
                with cols[0]:
                    h = st.selectbox(
                        f"Home stat col #{i+1}",
                        options=[""] + sheet_df.columns.tolist(),
                        index=(1 + sheet_df.columns.get_loc(auto_pairs[i][0])) if i < len(auto_pairs) else 0,
                        key=f"hcol_{i}",
                    )
                with cols[1]:
                    a = st.selectbox(
                        f"Away stat col #{i+1}",
                        options=[""] + sheet_df.columns.tolist(),
                        index=(1 + sheet_df.columns.get_loc(auto_pairs[i][1])) if i < len(auto_pairs) else 0,
                        key=f"acol_{i}",
                    )
                with cols[2]:
                    nm_default = auto_pairs[i][2] if i < len(auto_pairs) else ""
                    nm = st.text_input(
                        f"Unified name #{i+1}",
                        value=nm_default,
                        key=f"nm_{i}",
                        placeholder="e.g., Shots, ShotsOnTarget, Fouls",
                    )
                with cols[3]:
                    st.write("")  # spacing
                    st.write("")

                if h and a and nm:
                    pairs.append((h, a, nm))

        st.divider()

        st.subheader("3) (Optional) Columns to Carry to Both Sides")
        st.caption("Pick any columns you want copied to both rows (e.g., Date, Referee, League, Venue, etc.).")
        all_cols = sheet_df.columns.tolist()
        # By default, suggest basic time/identity columns
        suggested_carries = [c for c in all_cols if re.search(r"(date|time|ref|league|div|venue|round|match)", c, re.I)]
        carry_cols = st.multiselect(
            "Carry columns",
            options=all_cols,
            default=[c for c in suggested_carries if c not in {home_col, away_col}],
        )

        st.divider()

        st.subheader("4) (Optional) Player Columns → Single 'PlayerName' Column")
        st.caption(
            "Select player columns for each side. They will be melted into a long table with columns "
            "[MatchID, Team, Home/Away, PlayerName]. Leave empty if your file doesn't have player names."
        )

        default_home_players = [c for c in all_cols if re.match(r"home.*player|player.*home|^hp\d*$", c, re.I)]
        default_away_players = [c for c in all_cols if re.match(r"away.*player|player.*away|^ap\d*$", c, re.I)]

        cph, cpa = st.columns(2)
        with cph:
            player_cols_home = st.multiselect(
                "Home player columns",
                options=all_cols,
                default=default_home_players,
                help="Example: HomePlayer1, HomePlayer2, ...",
            )
        with cpa:
            player_cols_away = st.multiselect(
                "Away player columns",
                options=all_cols,
                default=default_away_players,
                help="Example: AwayPlayer1, AwayPlayer2, ...",
            )

        st.divider()

        copt1, copt2 = st.columns(2)
        with copt1:
            make_cats = st.checkbox("Convert string columns to 'category' dtype (saves memory)", value=True)
        with copt2:
            st.write("")  # spacing

        # -------------------- Transform Button & Results ---------------------

        run = st.button("🔄 Convert to Teamwise")

        if run:
            try:
                cfg = TransformConfig(
                    home_team_col=home_col,
                    away_team_col=away_col,
                    carry_cols=carry_cols,
                    stat_pairs=pairs,
                    player_cols_home=player_cols_home,
                    player_cols_away=player_cols_away,
                    create_categoricals=make_cats,
                    match_id_col=match_id_col,
                )
                teamwise, players_long = to_teamwise(sheet_df, cfg)

                st.success(
                    f"Converted {len(sheet_df)} match rows → {len(teamwise)} team rows "
                    f"(~2×, accounting for any dropped/nulls)."
                )

                cprev1, cprev2 = st.columns(2)
                with cprev1:
                    st.subheader("Teamwise Preview")
                    st.dataframe(df_head_safe(teamwise, 40), use_container_width=True, height=420)
                with cprev2:
                    st.subheader("Players Long Preview")
                    if players_long.empty:
                        st.info("No player columns selected or no non-empty names found.")
                    else:
                        st.dataframe(df_head_safe(players_long, 40), use_container_width=True, height=420)

                # Downloads
                st.subheader("📥 Download")
                bytes_team = bytes_excel_multi({"Teamwise": teamwise})
                st.download_button(
                    "Download Teamwise (Excel)",
                    data=bytes_team,
                    file_name="teamwise.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                )

                if not players_long.empty:
                    bytes_both = bytes_excel_multi({"Teamwise": teamwise, "PlayersLong": players_long})
                    st.download_button(
                        "Download Teamwise + PlayersLong (Excel, 2 sheets)",
                        data=bytes_both,
                        file_name="teamwise_with_players.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    )

                st.caption("Tip: If you prefer 'For'/'Against' style stats, you can compute them after download.")
            except Exception as exc:
                st.error(f"Conversion failed: {exc}")

    except Exception as e:
        st.error(f"Failed to read Excel: {e}")

else:
    st.info("Upload an Excel file to begin.")

# =============================== Footer ======================================

with st.expander("About this app"):
    st.markdown(
        """
**What this app does**

- Works with *any* Excel file (sports, e-sports, games, etc.) that has per-match rows.
- Lets you tell the app which columns represent:
  - Home Team, Away Team
  - Optional stat pairs (Home col + Away col → unified stat name)
  - Optional carry columns (copied to both sides)
  - Optional player columns for each side (melted into one `PlayerName` column)

**Why you saw 'Missing B365*' before**

- The earlier code required fixed betting-odds columns (`B365H/B365D/B365A`).  
- This app removes all hard-coded requirements. You can upload any Excel and simply choose the relevant columns.

**Notes**

- If your data has abbreviations like `HS/AS` or `HST/AST`, the app tries to auto-suggest pairs.  
- Everything is editable—use the dropdowns to fix suggestions if needed.
"""
    )
