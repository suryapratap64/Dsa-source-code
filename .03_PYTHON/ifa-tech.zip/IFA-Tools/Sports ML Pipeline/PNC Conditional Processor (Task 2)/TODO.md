[x] 1. minimum matching rows threshold 
[x] 2. Date for testing and validation
[x] 3. greater than, less than, AND OR logic
[] 4. Fix Name Categorical 
[] 5. Numbers to categorical
