# filepath: /data-analysis-tool/data-analysis-tool/config.py
DEFAULT_THRESHOLD = 0.0
SUPPORTED_FILE_TYPES = ['xlsx', 'xls']
ANALYSIS_OPTIONS = ['mean', 'median', 'mode']
RESULTS_SHEET_NAME = 'Analysis Results'
MAX_ROWS_DISPLAY = 200
