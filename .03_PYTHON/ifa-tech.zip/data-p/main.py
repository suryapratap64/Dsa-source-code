import streamlit as st
import pandas as pd
import numpy as np
from io import BytesIO
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Page config
st.set_page_config(
    page_title="Excel Data Transformer",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better UI
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        text-align: center;
        color: #1e3a8a;
        margin-bottom: 2rem;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
    }
    .sub-header {
        font-size: 1.5rem;
        color: #374151;
        margin-bottom: 1rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin: 0.5rem 0;
    }
    .success-box {
        background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        margin: 1rem 0;
    }
    .info-box {
        background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        margin: 1rem 0;
    }
    .sidebar .sidebar-content {
        background: linear-gradient(180deg, #f7fafc 0%, #edf2f7 100%);
    }
    .stFileUploader > div > div > div {
        border: 2px dashed #4299e1;
        border-radius: 10px;
        background: linear-gradient(135deg, #ebf8ff 0%, #bee3f8 100%);
    }
</style>
""", unsafe_allow_html=True)

def calculate_statistics(data, id_col, win_col, lose_col, win_rate_col, reach_col, stance_col, prob_col, profit_col):
    """Calculate all required statistics for the data"""
    results = {}
    
    # Basic counts
    results['count'] = len(data)
    results['win_sum'] = data[win_col].sum() if win_col in data.columns else 0
    results['win_mean'] = data[win_col].mean() if win_col in data.columns else 0
    results['win_std'] = data[win_col].std() if win_col in data.columns else 0
    
    # Win/Lose lists and counts
    results['win_actual_list'] = data[win_col].tolist() if win_col in data.columns else []
    results['lose_actual_list'] = data[lose_col].tolist() if lose_col in data.columns else []
    results['id_list'] = data[id_col].tolist() if id_col in data.columns else []
    
    # Rolling average calculation
    if win_col in data.columns:
        rolling_avg = data[win_col].expanding().mean().tolist()
        results['rolling_avg'] = rolling_avg
    else:
        results['rolling_avg'] = []
    
    # Win consistency (std/mean ratio)
    if results['win_mean'] != 0:
        results['win_consistency'] = results['win_std'] / results['win_mean']
    else:
        results['win_consistency'] = 0
    
    # Run calculations
    win_list = results['win_actual_list']
    if win_list:
        runs = calculate_runs(win_list)
        results.update(runs)
    else:
        results.update({
            'total_runs_count': 0,
            'win_runs_count': 0,
            'max_win_run_length': 0,
            'max_win_run_count': 0,
            'loss_runs_count': 0,
            'max_loss_run_length': 0,
            'max_loss_run_count': 0
        })
    
    # Profit calculations
    if profit_col in data.columns:
        results['profit_sum'] = data[profit_col].sum()
        results['profit_mean'] = data[profit_col].mean()
        results['profit_list'] = data[profit_col].tolist()
    else:
        results['profit_sum'] = 0
        results['profit_mean'] = 0
        results['profit_list'] = []
    
    return results

def calculate_runs(win_list):
    """Calculate run statistics from win/loss list"""
    if not win_list:
        return {
            'total_runs_count': 0,
            'win_runs_count': 0,
            'max_win_run_length': 0,
            'max_win_run_count': 0,
            'loss_runs_count': 0,
            'max_loss_run_length': 0,
            'max_loss_run_count': 0
        }
    
    runs = []
    current_run = [win_list[0]]
    
    for i in range(1, len(win_list)):
        if win_list[i] == current_run[-1]:
            current_run.append(win_list[i])
        else:
            runs.append(current_run)
            current_run = [win_list[i]]
    runs.append(current_run)
    
    win_runs = [run for run in runs if run[0] == 1]
    loss_runs = [run for run in runs if run[0] == 0]
    
    max_win_run_length = max([len(run) for run in win_runs]) if win_runs else 0
    max_loss_run_length = max([len(run) for run in loss_runs]) if loss_runs else 0
    
    return {
        'total_runs_count': len(runs),
        'win_runs_count': len(win_runs),
        'max_win_run_length': max_win_run_length,
        'max_win_run_count': win_runs.count([1] * max_win_run_length) if max_win_run_length > 0 else 0,
        'loss_runs_count': len(loss_runs),
        'max_loss_run_length': max_loss_run_length,
        'max_loss_run_count': loss_runs.count([0] * max_loss_run_length) if max_loss_run_length > 0 else 0
    }

def create_binned_columns(df, columns_to_bin):
    """Create binned versions of specified columns"""
    for col in columns_to_bin:
        if col in df.columns:
            # Create bins based on quartiles
            df[f'{col}_bin'] = pd.qcut(df[col], q=4, labels=['Low', 'Medium-Low', 'Medium-High', 'High'], duplicates='drop')
    return df

def apply_filters(df, filters):
    """Apply filters to dataframe based on conditions"""
    filtered_df = df.copy()
    
    for filter_condition in filters:
        if filter_condition['column'] in df.columns:
            col = filter_condition['column']
            operator = filter_condition['operator']
            value = filter_condition['value']
            
            if operator == '>=':
                filtered_df = filtered_df[filtered_df[col] >= value]
            elif operator == '<=':
                filtered_df = filtered_df[filtered_df[col] <= value]
            elif operator == '<':
                filtered_df = filtered_df[filtered_df[col] < value]
            elif operator == '>':
                filtered_df = filtered_df[filtered_df[col] > value]
            elif operator == '==':
                filtered_df = filtered_df[filtered_df[col] == value]
    
    return filtered_df

def transform_data(df):
    """Main transformation function"""
    # Define column mappings based on the reference data
    x_columns = {
        'win': 'NumberOf_WIN_x',
        'lose': 'NumberOf_LOSE_x', 
        'win_rate': 'WIN_RATE_x',
        'reach': 'Reach Inches_x',
        'stance': 'Stance_x',
        'probability': 'probability_x_win',
        'fight_id': 'Fight ID_x'
    }
    
    y_columns = {
        'win': 'NumberOf_WIN_y',
        'lose': 'NumberOf_LOSE_y',
        'win_rate': 'WIN_RATE_y', 
        'reach': 'Reach Inches_y',
        'stance': 'Stance_y',
        'probability': 'probability_y_win',
        'fight_id': 'Fight ID_y'
    }
    
    # Create binned columns
    columns_to_bin = ['NumberOf_WIN_x', 'NumberOf_LOSE_x', 'WIN_RATE_x', 'Reach Inches_x', 
                      'NumberOf_WIN_y', 'NumberOf_LOSE_y', 'WIN_RATE_y', 'Reach Inches_y']
    df = create_binned_columns(df, columns_to_bin)
    
    # Sample filter conditions (these would be dynamic based on user input)
    sample_filters = [
        {'column': 'probability_x_win', 'operator': '<', 'value': 0.6},
        {'column': 'NumberOf_WIN_y', 'operator': '>=', 'value': 4.5},
        {'column': 'NumberOf_LOSE_y', 'operator': '>=', 'value': 2.7},
        {'column': 'WIN_RATE_y', 'operator': '>=', 'value': 0.5}
    ]
    
    # Apply filters
    filtered_data = apply_filters(df, sample_filters)
    
    # Calculate statistics for both x and y data
    profit_col = 'profit' if 'profit' in df.columns else None
    
    x_stats = calculate_statistics(
        filtered_data, 
        x_columns['fight_id'], x_columns['win'], x_columns['lose'], 
        x_columns['win_rate'], x_columns['reach'], x_columns['stance'], 
        x_columns['probability'], profit_col
    )
    
    y_stats = calculate_statistics(
        filtered_data,
        y_columns['fight_id'], y_columns['win'], y_columns['lose'],
        y_columns['win_rate'], y_columns['reach'], y_columns['stance'], 
        y_columns['probability'], profit_col
    )
    
    # Create output row
    output_row = {
        # X statistics
        'NumberOf_WIN_x_bin': x_columns['win'],
        'NumberOf_LOSE_x_bin': x_columns['lose'], 
        'WIN_RATE_x_bin': x_columns['win_rate'],
        'Reach Inches_x_bin': x_columns['reach'],
        'Stance_x_bin': x_columns['stance'],
        'probability_x_win_bin': x_columns['probability'],
        
        # Y statistics  
        'NumberOf_WIN_y_bin': y_columns['win'],
        'NumberOf_LOSE_y_bin': y_columns['lose'],
        'WIN_RATE_y_bin': y_columns['win_rate'], 
        'Reach Inches_y_bin': y_columns['reach'],
        'Stance_y_bin': y_columns['stance'],
        'probability_y_win_bin': y_columns['probability'],
        
        # X detailed stats
        'Fight ID_x_list': tuple(x_stats['id_list']),
        'x_win_actual_count': x_stats['count'],
        'x_win_actual_sum': x_stats['win_sum'],
        'x_win_actual_mean': x_stats['win_mean'],
        'x_win_actual_std': x_stats['win_std'],
        'x_win_actual_list': tuple(x_stats['win_actual_list']),
        'x_win_Rolling_Avg': x_stats['rolling_avg'],
        'x_win_consistency': x_stats['win_consistency'],
        'total_runs_count_x': x_stats['total_runs_count'],
        'win_runs_count_x': x_stats['win_runs_count'],
        'max_win_run_length_x': x_stats['max_win_run_length'],
        'max_win_run_count_x': x_stats['max_win_run_count'],
        'loss_runs_count_x': x_stats['loss_runs_count'],
        'max_loss_run_length_x': x_stats['max_loss_run_length'],
        'max_loss_run_count_x': x_stats['max_loss_run_count'],
        'profit_x_sum': x_stats['profit_sum'],
        'profit_x_mean': x_stats['profit_mean'],
        'profit_x_list': tuple(x_stats['profit_list']),
        
        # Y detailed stats
        'Fight ID_y_list': tuple(y_stats['id_list']),
        'y_win_actual_count': y_stats['count'],
        'y_win_actual_sum': y_stats['win_sum'],
        'y_win_actual_mean': y_stats['win_mean'],
        'y_win_actual_std': y_stats['win_std'],
        'y_win_actual_list': tuple(y_stats['win_actual_list']),
        'y_win_Rolling_Avg': y_stats['rolling_avg'],
        'y_win_consistency': y_stats['win_consistency'],
        'total_runs_count_y': y_stats['total_runs_count'],
        'win_runs_count_y': y_stats['win_runs_count'],
        'max_win_run_length_y': y_stats['max_win_run_length'],
        'max_win_run_count_y': y_stats['max_win_run_count'],
        'loss_runs_count_y': y_stats['loss_runs_count'],
        'max_loss_run_length_y': y_stats['max_loss_run_length'],
        'max_loss_run_count_y': y_stats['max_loss_run_count'],
        'profit_y_sum': y_stats['profit_sum'],
        'profit_y_mean': y_stats['profit_mean'],
        'profit_y_list': tuple(y_stats['profit_list'])
    }
    
    return pd.DataFrame([output_row])

def create_visualizations(input_df, output_df):
    """Create visualization charts"""
    
    # Win Rate Distribution
    fig1 = px.histogram(
        input_df, 
        x='WIN_RATE_x' if 'WIN_RATE_x' in input_df.columns else input_df.columns[0],
        title="Win Rate Distribution",
        color_discrete_sequence=['#4299e1']
    )
    fig1.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        title_font_size=20,
        title_x=0.5
    )
    
    # Profit Analysis
    if 'profit' in input_df.columns:
        fig2 = px.box(
            input_df,
            y='profit',
            title="Profit Distribution",
            color_discrete_sequence=['#48bb78']
        )
    else:
        fig2 = px.bar(
            x=['Sample Data'],
            y=[100],
            title="Sample Profit Analysis",
            color_discrete_sequence=['#48bb78']
        )
    
    fig2.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        title_font_size=20,
        title_x=0.5
    )
    
    return fig1, fig2

def main():
    # Header
    st.markdown('<h1 class="main-header">📊 Excel Data Transformer</h1>', unsafe_allow_html=True)
    
    # Sidebar
    with st.sidebar:
        st.markdown("### ⚙️ Configuration")
        st.markdown("Upload your Excel file and configure transformation settings.")
        
        # File upload
        uploaded_file = st.file_uploader(
            "Choose Excel file",
            type=['xlsx', 'xls'],
            help="Upload your Excel file containing the data to be transformed"
        )
        
        if uploaded_file:
            st.markdown('<div class="success-box">✅ File uploaded successfully!</div>', unsafe_allow_html=True)
        
        # Transformation options
        st.markdown("### 🔧 Transformation Options")
        enable_binning = st.checkbox("Enable Column Binning", value=True)
        enable_filtering = st.checkbox("Apply Default Filters", value=True)
        enable_statistics = st.checkbox("Calculate Advanced Statistics", value=True)
        
    # Main content
    if uploaded_file is not None:
        try:
            # Load data
            with st.spinner('Loading data...'):
                df = pd.read_excel(uploaded_file)
            
            # Display input data info
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.markdown(f'''
                <div class="metric-card">
                    <h3>📋 Total Rows</h3>
                    <h2>{len(df):,}</h2>
                </div>
                ''', unsafe_allow_html=True)
            
            with col2:
                st.markdown(f'''
                <div class="metric-card">
                    <h3>📊 Total Columns</h3>
                    <h2>{len(df.columns)}</h2>
                </div>
                ''', unsafe_allow_html=True)
            
            with col3:
                numeric_cols = df.select_dtypes(include=[np.number]).columns
                st.markdown(f'''
                <div class="metric-card">
                    <h3>🔢 Numeric Columns</h3>
                    <h2>{len(numeric_cols)}</h2>
                </div>
                ''', unsafe_allow_html=True)
            
            with col4:
                missing_values = df.isnull().sum().sum()
                st.markdown(f'''
                <div class="metric-card">
                    <h3>❓ Missing Values</h3>
                    <h2>{missing_values:,}</h2>
                </div>
                ''', unsafe_allow_html=True)
            
            # Tabs for different sections
            tab1, tab2, tab3, tab4 = st.tabs(["📋 Input Data", "🔄 Transform Data", "📊 Visualizations", "📥 Download"])
            
            with tab1:
                st.markdown('<h2 class="sub-header">Input Data Preview</h2>', unsafe_allow_html=True)
                st.dataframe(df.head(10), use_container_width=True)
                
                with st.expander("📈 Data Summary"):
                    st.write("**Column Information:**")
                    col_info = pd.DataFrame({
                        'Column': df.columns,
                        'Data Type': df.dtypes,
                        'Non-Null Count': df.count(),
                        'Null Count': df.isnull().sum()
                    })
                    st.dataframe(col_info, use_container_width=True)
            
            with tab2:
                st.markdown('<h2 class="sub-header">Data Transformation</h2>', unsafe_allow_html=True)
                
                if st.button("🚀 Transform Data", type="primary", use_container_width=True):
                    with st.spinner('Transforming data...'):
                        try:
                            transformed_df = transform_data(df)
                            st.session_state.transformed_data = transformed_df
                            
                            st.markdown('<div class="success-box">✅ Data transformation completed successfully!</div>', unsafe_allow_html=True)
                            
                            # Show transformation summary
                            st.markdown("### 📊 Transformation Summary")
                            col1, col2 = st.columns(2)
                            
                            with col1:
                                st.metric("Input Rows", len(df))
                                st.metric("Output Rows", len(transformed_df))
                            
                            with col2:
                                st.metric("Input Columns", len(df.columns))
                                st.metric("Output Columns", len(transformed_df.columns))
                            
                            # Preview transformed data
                            st.markdown("### 👁️ Transformed Data Preview")
                            st.dataframe(transformed_df, use_container_width=True)
                            
                        except Exception as e:
                            st.error(f"Transformation failed: {str(e)}")
            
            with tab3:
                st.markdown('<h2 class="sub-header">Data Visualizations</h2>', unsafe_allow_html=True)
                
                if 'transformed_data' in st.session_state:
                    fig1, fig2 = create_visualizations(df, st.session_state.transformed_data)
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        st.plotly_chart(fig1, use_container_width=True)
                    with col2:
                        st.plotly_chart(fig2, use_container_width=True)
                else:
                    st.markdown('<div class="info-box">ℹ️ Please transform the data first to see visualizations.</div>', unsafe_allow_html=True)
            
            with tab4:
                st.markdown('<h2 class="sub-header">Download Results</h2>', unsafe_allow_html=True)
                
                if 'transformed_data' in st.session_state:
                    # Create download buffer
                    buffer = BytesIO()
                    with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
                        st.session_state.transformed_data.to_excel(writer, sheet_name='Transformed_Data', index=False)
                        df.to_excel(writer, sheet_name='Original_Data', index=False)
                    
                    st.download_button(
                        label="📥 Download Excel File",
                        data=buffer.getvalue(),
                        file_name="transformed_data.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        type="primary",
                        use_container_width=True
                    )
                    
                    st.markdown('<div class="success-box">📁 File includes both original and transformed data in separate sheets.</div>', unsafe_allow_html=True)
                    
                else:
                    st.markdown('<div class="info-box">ℹ️ Please transform the data first to enable download.</div>', unsafe_allow_html=True)
        
        except Exception as e:
            st.error(f"Error processing file: {str(e)}")
            st.info("Please ensure your Excel file has the correct format and required columns.")
    
    else:
        # Welcome screen
        st.markdown("""
        <div style="text-align: center; padding: 3rem;">
            <h2>Welcome to Excel Data Transformer! 🎯</h2>
            <p style="font-size: 1.2rem; color: #666;">
                Upload your Excel file to get started with advanced data transformation and analysis.
            </p>
            <br>
            <div style="display: flex; justify-content: center; gap: 2rem; flex-wrap: wrap;">
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 1.5rem; border-radius: 10px; color: white; min-width: 250px;">
                    <h3>📊 Advanced Analytics</h3>
                    <p>Calculate win rates, profit margins, and statistical metrics</p>
                </div>
                <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); padding: 1.5rem; border-radius: 10px; color: white; min-width: 250px;">
                    <h3>🔄 Data Transformation</h3>
                    <p>Apply filters, create bins, and generate new columns</p>
                </div>
                <div style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); padding: 1.5rem; border-radius: 10px; color: white; min-width: 250px;">
                    <h3>📈 Visualizations</h3>
                    <p>Interactive charts and graphs for better insights</p>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()